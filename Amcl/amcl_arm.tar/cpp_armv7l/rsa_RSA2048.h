/*
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
*/

/**
 * @file rsa.h
 * @author Mike Scott and Kealan McCusker
 * @date 2nd June 2015
 * @brief RSA Header file for implementation of RSA protocol
 *
 * declares functions
 *
 */

#ifndef RSA_RSA2048_H
#define RSA_RSA2048_H

#include "ff_RSA2048.h"
#include "rsa_support.h"

using namespace amcl;

/*** START OF USER CONFIGURABLE SECTION -  ***/

#define HASH_TYPE_RSA_RSA2048 SHA256 /**< Chosen Hash algorithm */

/*** END OF USER CONFIGURABLE SECTION ***/

#define RFS_RSA2048 MODBYTES_B1024_28*FFLEN_RSA2048 /**< RSA Public Key Size in bytes */


namespace RSA2048 {

/**
	@brief Integer Factorisation Public Key
*/

typedef struct
{
    sign32 e;     /**< RSA exponent (typically 65537) */
    B1024_28::BIG n[FFLEN_RSA2048]; /**< An array of BIGs to store public key */
} rsa_public_key;

/**
	@brief Integer Factorisation Private Key
*/

typedef struct
{
    B1024_28::BIG p[FFLEN_RSA2048/2];  /**< secret prime p  */
    B1024_28::BIG q[FFLEN_RSA2048/2];  /**< secret prime q  */
    B1024_28::BIG dp[FFLEN_RSA2048/2]; /**< decrypting exponent mod (p-1)  */
    B1024_28::BIG dq[FFLEN_RSA2048/2]; /**< decrypting exponent mod (q-1)  */
    B1024_28::BIG c[FFLEN_RSA2048/2];  /**< 1/p mod q */
} rsa_private_key;

/* RSA Auxiliary Functions */

extern void RSA_KEY_PAIR(csprng *R,sign32 e,rsa_private_key* PRIV,rsa_public_key* PUB,octet *P, octet* Q);

/**	@brief RSA encryption of suitably padded plaintext
 *
	@param PUB the input RSA public key
	@param F is input padded message
	@param G is the output ciphertext
 */
extern void RSA_ENCRYPT(rsa_public_key* PUB,octet *F,octet *G);
/**	@brief RSA decryption of ciphertext
 *
	@param PRIV the input RSA private key
	@param G is the input ciphertext
	@param F is output plaintext (requires unpadding)

 */
extern void RSA_DECRYPT(rsa_private_key* PRIV,octet *G,octet *F);
/**	@brief Destroy an RSA private Key
 *
	@param PRIV the input RSA private key. Destroyed on output.
 */
extern void RSA_PRIVATE_KEY_KILL(rsa_private_key *PRIV);
/**	@brief Populates an RSA public key from an octet string
 *
	Creates RSA public key from big-endian base 256 form.
	@param x FF instance to be created from an octet string
	@param S input octet string
 */
extern void RSA_fromOctet(B1024_28::BIG *x,octet *S);
}


#endif
