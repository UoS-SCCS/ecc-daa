#ifndef CONFIG_BIG_B1024_28_H
#define CONFIG_BIG_B1024_28_H

#include"amcl.h"

// BIG stuff

#define MODBYTES_B1024_28 128  
#define BASEBITS_B1024_28 28 


#endif
