#ifndef CONFIG_BIG_B256_28_H
#define CONFIG_BIG_B256_28_H

#include"amcl.h"

// BIG stuff

#define MODBYTES_B256_28 32  
#define BASEBITS_B256_28 28 


#endif
